package cs3500.lec08;

import java.io.IOException;

/**
 * <Purpose of the file> Created by Ben on 2/9/2016.
 */
public interface CalcController {
  void go(Calculator calc) throws IOException;
}
