package cs3500.marblesolitaire.view;

import java.io.IOException;

//import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
//import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * class MarbleSolitaireTextView helps visualize the game board.
 */
public class MarbleSolitaireTextView implements MarbleSolitaireView {
  private MarbleSolitaireModelState ms;
  private Appendable out = System.out;

  /**
   * constructor for MarbleSolitaireTextView.
   *
   * @param ms a MarbleSolitaireModelState that will use this class'
   *           methods.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState ms) {
    if (ms == (null)) {
      throw new IllegalArgumentException("Parameters cannot be null.");
    }
    this.ms = ms;
  }

  /**
   * constructor for MarbleSolitaireTextView is
   * and implementation of MarbleSolitaireView that
   * handles the visualization of the game board.
   *
   * @param ms  the model state.
   * @param out appendable object that sends visual data to user.
   */
  public MarbleSolitaireTextView(MarbleSolitaireModelState ms, Appendable out)
          throws IllegalArgumentException {
    if (ms == null || out == null) {
      throw new IllegalArgumentException("Parameters cannot be null.");
    } else {
      this.ms = ms;
      this.out = out;
    }
  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    for (int row = 0; row < this.ms.getBoardSize(); row += 1) {
      for (int col = 0; col < this.ms.getBoardSize(); col += 1) {
        if (col < this.ms.getBoardSize() - 1) {
          if ((this.ms.getSlotAt(row, col).equals(MarbleSolitaireModelState.SlotState.Empty)
                  || this.ms.getSlotAt(row, col).equals(MarbleSolitaireModelState.SlotState.Marble))
                  && (this.ms.getSlotAt(row, col + 1).equals(
                  MarbleSolitaireModelState.SlotState.Invalid))) {
            if (this.ms.getSlotAt(row, col).equals(MarbleSolitaireModelState.SlotState.Marble)) {
              builder.append("O");
              break;
            } else if (this.ms.getSlotAt(row, col).equals(
                    MarbleSolitaireModelState.SlotState.Empty)) {
              builder.append("_");
              break;
            }
          } else {
            if (this.ms.getSlotAt(row, col).equals(
                    MarbleSolitaireModelState.SlotState.Marble)) {
              builder.append("O ");
            } else if (this.ms.getSlotAt(row, col).equals(
                    MarbleSolitaireModelState.SlotState.Empty)) {
              builder.append("_ ");
            } else {
              builder.append("  ");
            }
          }
        } else {
          if (this.ms.getSlotAt(row, col).equals(MarbleSolitaireModelState.SlotState.Marble)) {
            builder.append("O");
          } else if (this.ms.getSlotAt(row, col).equals(
                  MarbleSolitaireModelState.SlotState.Empty)) {
            builder.append("_");
          }
        }
      }
      if (row < this.ms.getBoardSize() - 1) {
        builder.append("\n");
      }
    }
    String str = builder.toString();
    return str;
  }

  @Override
  public void renderBoard() throws IOException {
    this.out.append(this.toString());
  }

  @Override
  public void renderMessage(String message) throws IOException {
    this.out.append(message);
  }

}
