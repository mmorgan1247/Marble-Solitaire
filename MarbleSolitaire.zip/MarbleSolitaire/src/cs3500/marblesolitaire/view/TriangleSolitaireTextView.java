package cs3500.marblesolitaire.view;

import java.io.IOException;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
//import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;

/**
 * class TriangleSolitaireView is an implementation of MarbleSolitaireView that
 * helps visualize the game board and transmit messages.
 */
public class TriangleSolitaireTextView implements MarbleSolitaireView {
  private MarbleSolitaireModelState tms;
  private Appendable out = System.out;

  /**
   * constructor for TriangleSolitaireView that takes in a
   * TriangleSolitaireModel.
   *
   * @param tms a TriangleSolitaireModel that the view represents.
   */
  public TriangleSolitaireTextView(MarbleSolitaireModelState tms) {
    if (tms == null) {
      throw new IllegalArgumentException();
    }
    this.tms = tms;
  }

  /** constructor for TriangleSolitaireTextView that instantiates
   * the model state and the appendable.
   *
   * @param tms the model state.
   * @param out the appendable that the view will use to transmit messages.
   */
  public TriangleSolitaireTextView(MarbleSolitaireModelState tms, Appendable out) {
    if (tms == null || out == null) {
      throw new IllegalArgumentException("Parameters cannot be null.");
    } else {
      this.tms = tms;
      this.out = out;
    }
  }

  /**
   * method toString converts the game board to a String.
   *
   * @return the game board as a String.
   */
  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    int startSize = tms.getBoardSize() - 1;
    for (int row = 0; row < this.tms.getBoardSize(); row += 1) {
      for (int startSpaces = startSize; startSpaces > 0; startSpaces -= 1) {
        builder.append(" ");
      }
      for (int col = 0; col < this.tms.getBoardSize(); col += 1) {
        if (tms.getSlotAt(row, col).equals(
                MarbleSolitaireModelState.SlotState.Marble)) {
          builder.append("O");
          if (col < row) {
            builder.append(" ");
          }
        } else if (tms.getSlotAt(row, col).equals(
                MarbleSolitaireModelState.SlotState.Empty)) {
          builder.append("_");
          if (col < row) {
            builder.append(" ");
          }
        }
      }
      if (row < this.tms.getBoardSize() - 1) {
        builder.append("\n");
      }
      startSize -= 1;
    }
    return builder.toString();
  }

  /**
   * method that transmits the game board to the user.
   *
   * @throws IOException when there is a stream error.
   */
  @Override
  public void renderBoard() throws IOException {
    this.out.append(this.toString());
  }

  /**
   * method that transmits a message to the user.
   *
   * @param message the message to be transmitted
   * @throws IOException when there is a stream error.
   */
  @Override
  public void renderMessage(String message) throws IOException {
    this.out.append(message);
  }
}
