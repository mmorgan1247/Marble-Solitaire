package cs3500.marblesolitaire.controller;

/**
 * interface MarbleSolitaireController handles input from the
 * user and represents a controller for the game.
 */
public interface MarbleSolitaireController {

  /**
   * method playGame begins the game of Marble Solitaire.
   */
  void playGame() throws IllegalArgumentException;
}
