package cs3500.marblesolitaire.controller;

import java.util.Scanner;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * class MarbleSolitaireControllerImpl is an implementation of
 * MarbleSolitaireController that is a controller of a
 * marble solitaire game.
 */
public class MarbleSolitaireControllerImpl implements MarbleSolitaireController {

  private MarbleSolitaireModel model;
  private MarbleSolitaireView view;
  private final Readable in;

  /**
   * constructor for MarbleSolitaireControllerImpl class
   * creates an implementation of the MarbleSolitaireController
   * to interact with the game.
   *
   * @param model the MarbleSolitaireModel used in the game.
   * @param view  the MarbleSolitaireView used in the game.
   * @param in    where user input is read by the code.
   * @throws IllegalArgumentException when any arguments are null.
   */
  public MarbleSolitaireControllerImpl(MarbleSolitaireModel model,
                                       MarbleSolitaireView view, Readable in)
          throws IllegalArgumentException {
    if (model == null || view == null || in == null) {
      throw new IllegalArgumentException("Parameters cannot be null");
    } else {
      this.model = model;
      this.view = view;
      this.in = in;
    }
  }

  /**
   * void method that starts the marble solitaire game.
   *
   * @throws IllegalStateException when invalid input
   *                               is detected or when an IOException occurs within a stream.
   */
  @Override
  public void playGame() throws IllegalStateException {
    Scanner scan = new Scanner(this.in);

    boolean hasQuit = false;
    boolean hasInput = true;
    while (!model.isGameOver()) {
      try {
        this.view.renderBoard();
        this.view.renderMessage("\nScore: " + this.model.getScore() + "\n");
        int[] inputs = new int[4];
        for (int it = 0; it < 4; it += 1) {
          if (scan.hasNext()) {
            String s = scan.next();
            try {
              int toMove = Integer.parseInt(s) - 1;
              if (toMove < 0) {
                this.view.renderMessage("Invalid move. Play again.");
                it -= 1;
                throw new IllegalStateException("Invalid render. ");
              } else {
                inputs[it] = toMove;
              }
            } catch (Exception numberFormatException) {
              if (s.equals("q") || s.equals("Q")) {
                hasQuit = true;
                break;
              } else {
                it -= 1;
              }
            }
          } else {
            hasInput = false;
            break;
          }
        }
        if (!hasInput) {
          throw new IllegalStateException();
        }

        if (hasQuit) {
          break;
        }
        try {
          model.move(inputs[0], inputs[1], inputs[2], inputs[3]);
        } catch (Exception illegalArgumentException) {
          this.view.renderMessage("Invalid Input. ");
        }
      } catch (Exception iOException) {
        throw new IllegalStateException();
      }
    }
    endMessage(hasQuit);
  }

  private void endMessage(Boolean hasQuit) {
    try {
      if (hasQuit) {
        this.view.renderMessage("Game quit!\nState of game when quit:\n");
      } else {
        this.view.renderMessage("Game over!\n");
      }
      this.view.renderBoard();
      this.view.renderMessage("\nScore: " + this.model.getScore());
    } catch (Exception iOException) {
      throw new IllegalStateException();
    }
  }
}
