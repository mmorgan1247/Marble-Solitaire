package cs3500.marblesolitaire;

import java.io.InputStreamReader;
//import java.io.PrintStream;

import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
//import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;
import cs3500.marblesolitaire.view.TriangleSolitaireTextView;

/**
 * class play enables me to play my game.
 */
public final class MarbleSolitaire {

  /**
   * main method that starts the game so that I can play.
   *
   * @param args takes args from the command line.
   */
  public static void main(String[] args) {
    MarbleSolitaireModel model = null;
    MarbleSolitaireView view = null;
    MarbleSolitaireController controller;
    int thickness = 0;
    int emptyX = 0;
    int emptyY = 0;

    boolean hasThickness = false;
    boolean hasHole = false;
    for (int element = 1; element < args.length; element += 1) {
      if (args[element].equals("-size")) {
        thickness = Integer.parseInt(args[element + 1]);
        hasThickness = true;
      }
      if (args[element].equals("-hole")) {
        emptyX = Integer.parseInt(args[element + 1]);
        emptyY = Integer.parseInt(args[element + 2]);
        hasHole = true;
      }
    }
    if (args[0].equalsIgnoreCase("english")) {
      if (hasHole && hasThickness) {
        model = new EnglishSolitaireModel(thickness, emptyX, emptyY);
      } else if (hasHole && !hasThickness) {
        model = new EnglishSolitaireModel(emptyX, emptyY);
      } else if (!hasHole && hasThickness) {
        model = new EnglishSolitaireModel(thickness);
      } else {
        model = new EnglishSolitaireModel();
      }
      view = new MarbleSolitaireTextView(model);
    } else if (args[0].equalsIgnoreCase("triangle")) {
      if (hasHole && hasThickness) {
        model = new TriangleSolitaireModel(thickness, emptyX, emptyY);
      } else if (hasHole && !hasThickness) {
        model = new TriangleSolitaireModel(emptyX, emptyY);
      } else if (!hasHole && hasThickness) {
        model = new TriangleSolitaireModel(thickness);
      } else {
        model = new TriangleSolitaireModel();
      }
      view = new TriangleSolitaireTextView(model);
    } else if (args[0].equalsIgnoreCase("european")) {
      if (hasHole && hasThickness) {
        model = new EuropeanSolitaireModel(thickness, emptyX, emptyY);
      } else if (hasHole && !hasThickness) {
        model = new EuropeanSolitaireModel(emptyX, emptyY);
      } else if (!hasHole && hasThickness) {
        model = new EuropeanSolitaireModel(thickness);
      } else {
        model = new EuropeanSolitaireModel();
      }
      view = new MarbleSolitaireTextView(model);
    }
    Readable readable = new InputStreamReader(System.in);
    controller = new MarbleSolitaireControllerImpl(
            model, view, readable);
    controller.playGame();
  }
}
