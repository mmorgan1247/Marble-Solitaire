package cs3500.marblesolitaire.model.hw02;

//import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
//import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

import cs3500.marblesolitaire.model.AbsSolitaireModel;

/**
 * EnglishSolitaireModel class represents a gridded game board
 * in a 2D array. Int thickness represents the width of each arm.
 */
public class EnglishSolitaireModel extends AbsSolitaireModel {
  /**
   * This EnglishSolitaireModel constructor takes no arguments
   * and initializes the thickness at 3.
   */
  public EnglishSolitaireModel() {
    super();
  }

  /**
   * This EnglishSolitaire constructor takes blank position arguments.
   *
   * @param sRow represents the y value of the blank space.
   * @param sCol represents the x value of the blank space.
   */
  public EnglishSolitaireModel(int sRow, int sCol) {
    super(sRow, sCol);
  }

  /**
   * This EnglishSolitaireModel constructor takes in a thickness argument.
   *
   * @param thickness represents the width of each arm.
   */
  public EnglishSolitaireModel(int thickness) {
    super(thickness);
  }

  /**
   * This EnglishSolitaireModel constructor takes in three arguments
   * to allow for more customization of the board.
   *
   * @param thickness represents the width of each arm.
   * @param sRow      represents the y value of the blank space.
   * @param sCol      represents the x value of the blank space.
   */
  public EnglishSolitaireModel(int thickness, int sRow, int sCol) {
    super(thickness, sRow, sCol);
  }

  /**
   * fillBoard method helps the constructors fill the 2d array given the
   * arguments given to the constructors. It is public so that the parent
   * class may access it.
   */
  @Override
  public void fillBoard() {
    for (int row = 0; row <= this.getBoardSize() - 1; row++) {
      for (int col = 0; col <= this.getBoardSize() - 1; col++) {
        if ((col < thickness - 1 && row < thickness - 1)
                || (col > this.getBoardSize() - thickness && row < thickness - 1)
                || (col > this.getBoardSize() - thickness && row > this.getBoardSize() - thickness)
                || (col < thickness - 1 && row > this.getBoardSize() - thickness)) {
          arr[row][col] = MarbleSolitaireModelState.SlotState.Invalid;
        } else {
          arr[row][col] = MarbleSolitaireModelState.SlotState.Marble;
        }
      }
    }
  }

  /**
   * makeOver method exists to help test the isGameOver method -
   * it will make the board unplayable.
   */
  public void makeOver() {
    for (int row = this.getBoardSize() - 2; row >= 0; row -= 2) {
      for (int col = this.getBoardSize() - 2; col >= 0; col--) {
        this.arr[row][col] = SlotState.Empty;
        this.arr[thickness + 1][col] = SlotState.Empty;
      }
    }
  }
}

