package cs3500.marblesolitaire.model;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * abstract class AbsSolitaireModel abstracts some implementations
 * of the MarbleSolitaireModel interface.
 */
public abstract class AbsSolitaireModel implements MarbleSolitaireModel {

  protected int thickness;

  protected SlotState[][] arr;

  /**
   * This AbsSolitaireModel constructor takes no arguments
   * and initializes the thickness at 3.
   */
  protected AbsSolitaireModel() {
    this.thickness = 3;
    arr = new SlotState[thickness * 3 - 2][thickness * 3 - 2];
    this.fillBoard();
    arr[thickness][thickness] = SlotState.Empty;
  }

  /**
   * This AbsSolitaireModel constructor takes in a thickness argument.
   *
   * @param thickness represents the width of each arm.
   */
  protected AbsSolitaireModel(int thickness) {
    if (thickness <= 0 || thickness % 2 == 0) {
      throw new IllegalArgumentException("Thickness must be a positive odd number");
    }
    this.thickness = thickness;
    arr = new SlotState[thickness * 3 - 2][thickness * 3 - 2];
    this.fillBoard();
    arr[this.getBoardSize() / 2][this.getBoardSize() / 2] = SlotState.Empty;
  }

  /**
   * This AbsSolitaireModel constructor takes blank position arguments.
   *
   * @param emptyX represents the y value of the blank space.
   * @param emptyY represents the x value of the blank space.
   */
  protected AbsSolitaireModel(int emptyX, int emptyY) {
    this.thickness = 3;
    arr = new SlotState[thickness * 3 - 2][thickness * 3 - 2];
    this.fillBoard();
    try {
      if (MarbleSolitaireModelState.SlotState.Invalid == this.getSlotAt(emptyX, emptyY)) {
        throw new IllegalArgumentException("Invalid empty cell position (" +
                emptyX + "," + emptyY);
      }
      arr[emptyX][emptyY] = SlotState.Empty;
    } catch (Exception arrayIndexOutOfBoundException) {
      throw new IllegalArgumentException("Out of bounds");
    }
  }

  /**
   * This AbsSolitaireModel constructor takes in three arguments
   * to allow for more customization of the board.
   *
   * @param thickness represents the width of each arm.
   * @param emptyX    represents the y value of the blank space.
   * @param emptyY    represents the x value of the blank space.
   */
  protected AbsSolitaireModel(int thickness, int emptyX, int emptyY) {
    if (thickness <= 0 || thickness % 2 == 0) {
      throw new IllegalArgumentException("Thickness must be a positive odd number");
    }
    this.thickness = thickness;
    try {
      arr = new SlotState[thickness * 3 - 2][thickness * 3 - 2];
      this.fillBoard();
      if (SlotState.Invalid == this.getSlotAt(emptyX, emptyY)) {
        throw new IllegalArgumentException("Invalid empty cell position (" +
                emptyX + "," + emptyY);
      }
      arr[emptyX][emptyY] = SlotState.Empty;
    } catch (Exception arrayIndexOutOfBoundException) {
      throw new IllegalArgumentException("Out of bounds");
    }
  }

  public abstract void fillBoard();

  /**
   * helper method outOfBoard returns if a given slot
   * is out of the game board.
   *
   * @param row the x value of the position.
   * @param col the y value of the position.
   * @return whether the value is out of the board.
   */
  private boolean outOfBoard(int row, int col) {
    return (row < 0 || row >= this.getBoardSize()
            || col < 0 || col >= this.getBoardSize());
  }


  /**
   * move method modifies the 2d array that represents the game board.
   *
   * @param fromRow the row number of the position to be moved from
   *                (starts at 0).
   * @param fromCol the column number of the position to be moved from
   *                (starts at 0).
   * @param toRow   the row number of the position to be moved to
   *                (starts at 0).
   * @param toCol   the column number of the position to be moved to
   *                (starts at 0).
   * @throws IllegalArgumentException when the to or from arguments represent
   *                                  an occupied or invalid space.
   */
  public void move(int fromRow, int fromCol, int toRow, int toCol) throws IllegalArgumentException {

    if (this.outOfBoard(fromRow, fromCol) || this.outOfBoard(toRow, toCol)
            || MarbleSolitaireModelState.SlotState.Invalid == this.getSlotAt(fromRow, fromCol)) {
      throw new IllegalArgumentException("Invalid Space."
              + fromRow +
              " " + fromCol + " " + toRow + " " + toCol);
    }
    switch (this.getSlotAt(fromRow, fromCol)) {
      case Invalid:
        //throws exception because arguments correspond to an invalid space.
        throw new IllegalArgumentException("Invalid Space.");
      case Empty:
        //throws exception because arguments correspond to an empty space.
        throw new IllegalArgumentException("Empty Space.");
      default:
        switch (this.getSlotAt(toRow, toCol)) {
          case Invalid:
            //throws exception because arguments correspond to an invalid space.
            throw new IllegalArgumentException("Invalid Space.");
          case Marble:
            //throws exception because arguments correspond to an occupied space.
            throw new IllegalArgumentException("Occupied Space.");
          default:
            if (Math.abs(fromRow - toRow) == 2
                    && Math.abs(fromCol - toCol) == 2) {
              //throws exception because arguments correspond to
              //spaces that are diagonal from each other.
              throw new IllegalArgumentException("Jump must be 2 spaces.");
            } else if ((Math.abs(fromRow - toRow) == 2
                    || Math.abs(fromCol - toCol) == 2) &&
                    (fromRow == toRow || fromCol == toCol)) {
              if (fromRow == toRow) {
                arr[fromRow][1 + Math.min(fromCol, toCol)] = SlotState.Empty;
              } else {
                arr[1 + Math.min(fromRow, toRow)][fromCol] = SlotState.Empty;
              }
              arr[fromRow][fromCol] = SlotState.Empty;

              arr[toRow][toCol] = SlotState.Marble;
            } else {
              //throws exception because arguments correspond to a space
              //that are diagonal from each other.
              throw new IllegalArgumentException("Jump cannot be diagonal.");
            }


        }


    }

  }

  /**
   * isGameOver method returns whether there are valid moves available.
   *
   * @return returns whether the game is over.
   */
  public boolean isGameOver() {
    for (int row = 0; row <= this.getBoardSize() - 1; row++) {
      for (int col = 0; col <= this.getBoardSize() - 1; col++) {
        if (hasValidMove(row, col) && this.getSlotAt(row, col) == SlotState.Marble) {
          return false;
        }
      }
    }
    return true;
  }

  private boolean hasValidMove(int row, int col) {

    if (row > 1) {
      if (this.getSlotAt(row - 1, col) == SlotState.Marble
              && this.getSlotAt(row - 2, col) == SlotState.Empty) {
        return true;
      }
    }

    if (row < this.getBoardSize() - 2) {
      if (this.getSlotAt(row + 1, col) == SlotState.Marble
              && this.getSlotAt(row + 2, col) == SlotState.Empty) {
        return true;
      }
    }

    if (col > 1) {
      if (this.getSlotAt(row, col - 1) == SlotState.Marble
              && this.getSlotAt(row, col - 2) == SlotState.Empty) {
        return true;
      }
    }

    if (col < this.getBoardSize() - 2) {
      if (this.getSlotAt(row, col + 1) == SlotState.Marble
              && this.getSlotAt(row, col + 2) == SlotState.Empty) {
        return true;
      }
    }

    return false;
  }

  /**
   * returns the length of the board.
   *
   * @return the length of the board.
   */
  public int getBoardSize() {
    return this.thickness * 3 - 2;
  }


  /**
   * method that returns the slotstate of a given postition.
   *
   * @param row the row of the position sought, starting at 0.
   * @param col the column of the position sought, starting at 0.
   * @return the slotstate of the given position.
   * @throws IllegalArgumentException when arguments correspond to an invalid space.
   */
  public SlotState getSlotAt(int row, int col)
          throws IllegalArgumentException {
    if (row < 0 || col < 0 || row > this.getBoardSize() - 1 || col > this.getBoardSize()) {
      throw new IllegalArgumentException("This is located beyond the dimensions of the board.");
    }
    return this.arr[row][col];
  }

  /**
   * method that returns the amount of available marbles.
   *
   * @return the score of the game.
   */
  public int getScore() {
    int count = 0;
    for (int row = 0; row <= this.getBoardSize() - 1; row++) {
      for (int col = 0; col <= this.getBoardSize() - 1; col++) {
        if (this.getSlotAt(row, col) == SlotState.Marble) {
          count += 1;
        }
      }
    }
    return count;
  }

}
