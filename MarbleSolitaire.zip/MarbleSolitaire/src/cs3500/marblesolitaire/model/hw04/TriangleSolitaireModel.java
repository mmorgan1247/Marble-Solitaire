package cs3500.marblesolitaire.model.hw04;

import cs3500.marblesolitaire.model.AbsSolitaireModel;
//import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * class TriangleSolitaireModel is an implementation of MarbleSolitaireModel
 * and represents a triangular game board of Marble Solitaire.
 */
public class TriangleSolitaireModel extends AbsSolitaireModel {


  /**
   * constructor for TriangleSolitaireModel that has no arguments
   * and instantiates the board with a thickness of 5 and
   * default empty slot.
   */
  public TriangleSolitaireModel() {
    this.thickness = 5;

    arr = new SlotState[this.thickness][this.thickness];
    this.fillBoard();
    arr[0][0] = SlotState.Empty;
  }

  /**
   * constructor for TriangleSolitaireModel that takes in an
   * argument for thickness and uses a default empty slot.
   *
   * @param thickness how many marbles wide the triangle is.
   */
  public TriangleSolitaireModel(int thickness) {
    if (thickness < 1) {
      throw new IllegalArgumentException();
    } else {
      this.thickness = thickness;
    }
    arr = new SlotState[this.thickness][this.thickness];
    this.fillBoard();
    arr[0][0] = SlotState.Empty;
  }

  /**
   * constructor for TriangleSolitaireModel that takes in arguments
   * for the position of the empty slot and instantiates the
   * thickness as 5.
   *
   * @param x the x value of the empty slot.
   * @param y the y value of the empty slot.
   */
  public TriangleSolitaireModel(int x, int y) {
    this.thickness = 5;
    if (outOfTriangleBoard(x, y)) {
      throw new IllegalArgumentException();
    }
    arr = new SlotState[this.thickness][this.thickness];
    this.fillBoard();
    arr[x][y] = SlotState.Empty;
  }

  /**
   * constructor for TriangleSolitaireModel that takes in arguments
   * for the thickness and the empty slot position.
   *
   * @param thickness how many marbles wide the triangle is.
   * @param x         the x value of the empty slot.
   * @param y         the y value of the empty slot.
   */
  public TriangleSolitaireModel(int thickness, int x, int y) {
    this.thickness = thickness;
    if (outOfTriangleBoard(x, y) || thickness < 1) {
      throw new IllegalArgumentException();
    }
    arr = new SlotState[this.thickness][this.thickness];
    this.fillBoard();
    arr[x][y] = SlotState.Empty;
  }

  /**
   * helper method outOfTriangleBoard returns if a given slot
   * is out of the game board.
   *
   * @param row the y value of the position.
   * @param col the x value of the position.
   * @return whether the value is out of the board.
   */
  private boolean outOfTriangleBoard(int row, int col) {
    return (row > this.thickness || col > this.thickness
            || row < 0 || col < 0 || col > row);
  }

  /**
   * move method modifies the 2d array that represents the game board.
   *
   * @param fromRow the row number of the position to be moved from
   *                (starts at 0).
   * @param fromCol the column number of the position to be moved from
   *                (starts at 0).
   * @param toRow   the row number of the position to be moved to
   *                (starts at 0).
   * @param toCol   the column number of the position to be moved to
   *                (starts at 0).
   * @throws IllegalArgumentException when the to or from arguments represent
   *                                  an occupied or invalid space.
   */
  @Override
  public void move(int fromRow, int fromCol, int toRow, int toCol) throws IllegalArgumentException {
    if (this.outOfTriangleBoard(fromRow, fromCol) || this.outOfTriangleBoard(toRow, toCol)
            || MarbleSolitaireModelState.SlotState.Invalid == this.getSlotAt(fromRow, fromCol)) {
      throw new IllegalArgumentException("Invalid Space."
              + fromRow +
              " " + fromCol + " " + toRow + " " + toCol);
    }
    switch (this.getSlotAt(fromRow, fromCol)) {
      case Invalid:
        //throws exception because arguments correspond to an invalid space.
        throw new IllegalArgumentException("Invalid Space.");
      case Empty:
        //throws exception because arguments correspond to an empty space.
        throw new IllegalArgumentException("Empty Space.");
      default:
        switch (this.getSlotAt(toRow, toCol)) {
          case Invalid:
            //throws exception because arguments correspond to an invalid space.
            throw new IllegalArgumentException("Invalid Space.");
          case Marble:
            //throws exception because arguments correspond to an occupied space.
            throw new IllegalArgumentException("Occupied Space.");
          default:
            boolean diagMoveAttempt = Math.abs(fromRow - toRow) == 2
                    && Math.abs(fromCol - toCol) == 2;
            boolean vertMoveAttempt = Math.abs(fromRow - toRow) == 2
                    && Math.abs(fromCol - toCol) == 0;
            boolean horizMoveAttempt = Math.abs(fromRow - toRow) == 0
                    && Math.abs(fromCol - toCol) == 2;
            if (diagMoveAttempt
                    && this.getSlotAt(Math.max(fromRow, toRow) - 1,
                    Math.max(fromCol, toCol) - 1) == SlotState.Marble) {
              arr[fromRow][fromCol] = SlotState.Empty;
              arr[Math.max(fromRow, toRow) - 1][Math.max(fromCol, toCol) - 1] = SlotState.Empty;
              arr[toRow][toCol] = SlotState.Marble;
            } else if (vertMoveAttempt
                    && this.getSlotAt(Math.max(fromRow, toRow) - 1,
                    fromCol) == SlotState.Marble) {
              arr[fromRow][fromCol] = SlotState.Empty;
              arr[Math.max(fromRow, toRow) - 1][fromCol] = SlotState.Empty;
              arr[toRow][toCol] = SlotState.Marble;
            } // THere is a missing case here.
            else if (horizMoveAttempt
                    && this.getSlotAt(fromRow, Math.max(fromCol, toCol) - 1) == SlotState.Marble) {
              arr[fromRow][fromCol] = SlotState.Empty;
              arr[fromRow][Math.max(fromCol, toCol) - 1] = SlotState.Empty;
              arr[toRow][toCol] = SlotState.Marble;
            } else {
              throw new IllegalArgumentException("Invalid move.");
            }

        }
    }
  }

  /**
   * fillBoard method helps the constructors fill the 2d array given the
   * arguments given to the constructors.
   */
  @Override
  public void fillBoard() {
    for (int row = 0; row < this.getBoardSize(); row++) {
      for (int col = 0; col < this.getBoardSize(); col++) {
        if (col <= row) {
          arr[row][col] = SlotState.Marble;
        } else {
          arr[row][col] = SlotState.Invalid;
        }
      }
    }
  }


  /**
   * method that is public so that the test class can use it, and
   * makes the game board unplayable.
   */
  public void makeOver() {
    for (int row = this.getBoardSize() - 2; row >= 0; row -= 2) {
      for (int col = this.getBoardSize() - 2; col >= 0; col--) {
        this.arr[row][col] = SlotState.Empty;

      }

    }

  }


  /**
   * isGameOver method returns whether there are valid moves available.
   *
   * @return returns whether the game is over.
   */
  @Override
  public boolean isGameOver() {
    for (int row = 0; row <= this.getBoardSize() - 1; row++) {
      for (int col = 0; col <= this.getBoardSize() - 1; col++) {
        if (hasValidMoveTriangle(row, col) && this.getSlotAt(row, col) == SlotState.Marble) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * method that checks if the given slot has a valid move.
   *
   * @param row y value of slot.
   * @param col x value of slot.
   * @return if it can move.
   */
  private boolean hasValidMoveTriangle(int row, int col) {

    if (row > 1) {
      if (this.getSlotAt(row - 1, col) == SlotState.Marble
              && this.getSlotAt(row - 2, col) == SlotState.Empty) {
        return true;
      }
    }

    if (row < this.getBoardSize() - 2) {
      if (this.getSlotAt(row + 1, col) == SlotState.Marble
              && this.getSlotAt(row + 2, col) == SlotState.Empty) {
        return true;
      }
    }

    if (col > 1) {
      if (this.getSlotAt(row, col - 1) == SlotState.Marble
              && this.getSlotAt(row, col - 2) == SlotState.Empty) {
        return true;
      }
    }

    if (col < this.getBoardSize() - 2) {
      if (this.getSlotAt(row, col + 1) == SlotState.Marble
              && this.getSlotAt(row, col + 2) == SlotState.Empty) {
        return true;
      }
    }

    if (col < this.getBoardSize() - 2 && row < this.getBoardSize() - 2) {
      if (this.getSlotAt(row + 1, col + 1) == SlotState.Marble
              && this.getSlotAt(row + 2, col + 2) == SlotState.Empty) {
        return true;
      }
    }
    if (col > 1 && row > 1) {
      if (this.getSlotAt(row - 1, col - 1) == SlotState.Marble
              && this.getSlotAt(row - 2, col - 2) == SlotState.Empty) {
        return true;
      }
    }
    return false;
  }

  /**
   * returns the length of the board.
   *
   * @return the length of the board.
   */
  @Override
  public int getBoardSize() {
    return this.thickness;
  }


}
