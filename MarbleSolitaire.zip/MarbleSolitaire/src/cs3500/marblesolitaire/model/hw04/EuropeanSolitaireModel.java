package cs3500.marblesolitaire.model.hw04;

import cs3500.marblesolitaire.model.AbsSolitaireModel;
//import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;

/**
 * class EuropeanSolitaireModel is an abstraction of
 * AbsSolitaireModel and represents a game of
 * European Solitaire.
 */
public class EuropeanSolitaireModel extends AbsSolitaireModel {

  /**
   * This EuropeanSolitaireModel constructor takes no arguments
   * and initializes the thickness at 3.
   */
  public EuropeanSolitaireModel() {
    super();
  }

  /**
   * This EuropeanSolitaireModel constructor takes in a thickness argument.
   *
   * @param thickness represents the width of each arm.
   */
  public EuropeanSolitaireModel(int thickness) {
    super(thickness);
  }

  /**
   * This EuropeanSolitaireModel constructor takes blank position arguments.
   *
   * @param emptyX represents the y value of the blank space.
   * @param emptyY represents the x value of the blank space.
   */
  public EuropeanSolitaireModel(int emptyX, int emptyY) {
    super(emptyX, emptyY);
  }

  /**
   * This EnglishSolitaireModel constructor takes in three arguments
   * to allow for more customization of the board.
   *
   * @param thickness represents the width of each arm.
   * @param emptyX    represents the y value of the blank space.
   * @param emptyY    represents the x value of the blank space.
   */
  public EuropeanSolitaireModel(int thickness, int emptyX, int emptyY) {
    super(thickness, emptyX, emptyY);
  }

  /**
   * method fillBoard is called by parent constructors and
   * fill out the 2d array that represents the game board with
   * different slot states. It is public so that the parent constructors
   * may access it.
   */
  @Override
  public void fillBoard() {
    int lastSpaceCounter = 1;
    //work in progress
    for (int row = 0; row < this.getBoardSize(); row += 1) {
      if (row < thickness) {
        for (int col = 0; col < thickness - 1 - row; col += 1) {
          arr[row][col] = SlotState.Invalid;
        }
        for (int col = thickness - 1 - row; col < thickness * 2 - 1 + row; col += 1) {
          arr[row][col] = SlotState.Marble;
        }
        for (int col = thickness * 2 - 1 + row; col < this.getBoardSize(); col += 1) {
          arr[row][col] = SlotState.Invalid;
        }
      } else if (row >= thickness * 2 - 1) {
        for (int col = 0; col < lastSpaceCounter; col += 1) {
          arr[row][col] = SlotState.Invalid;
        }
        for (int col = lastSpaceCounter; col < this.getBoardSize() - lastSpaceCounter;
             col += 1) {
          arr[row][col] = SlotState.Marble;
        }
        for (int col = this.getBoardSize() - lastSpaceCounter;
             col < this.getBoardSize(); col += 1) {
          arr[row][col] = SlotState.Invalid;
        }
        lastSpaceCounter += 1;
      } else {
        for (int col = 0; col < this.getBoardSize(); col += 1) {
          arr[row][col] = SlotState.Marble;
        }
      }
    }
  }

  /**
   * should change.
   */
  public void makeOver() {
    for (int row = this.getBoardSize() - 2; row >= 0; row -= 2) {
      for (int col = this.getBoardSize() - 2; col >= 0; col--) {
        this.arr[row][col] = SlotState.Empty;
        this.arr[thickness + 1][col] = SlotState.Empty;
      }

    }

  }
}
