import java.io.IOException;

import cs3500.marblesolitaire.view.MarbleSolitaireView;

/**
 * class MockView is a mock that implements the MarbleSolitaireView
 * class in order to help test the MarbleSolitaireController.
 */
public class MockView implements MarbleSolitaireView {
  @Override
  public void renderBoard() throws IOException {
    throw new IOException();
  }

  @Override
  public void renderMessage(String message) throws IOException {
    throw new IOException();
  }
}
