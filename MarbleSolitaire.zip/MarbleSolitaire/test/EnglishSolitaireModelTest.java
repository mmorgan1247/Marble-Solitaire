import org.junit.Test;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
//import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
//import cs3500.marblesolitaire.view.MarbleSolitaireTextView;

import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertThrows;

/**
 * class englishSolitaireModelTest tests the EnglishSolitaireModel and
 * MarbleSolitaireTextView classes.
 */
public class EnglishSolitaireModelTest {
  EnglishSolitaireModel esm = new EnglishSolitaireModel();
  EnglishSolitaireModel esm2 = new EnglishSolitaireModel(5);

  EnglishSolitaireModel esmCustom = new EnglishSolitaireModel(0, 2);

  EnglishSolitaireModel esmCustomBoth = new EnglishSolitaireModel(5, 0, 4);


  @Test
  public void testConstructor1() {

    assertEquals(esm.getBoardSize(), 7);
    assertEquals(esm.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Empty);
  }

  @Test
  public void testConstructor2() {
    assertEquals(esm2.getBoardSize(), 13);
    assertEquals(esm2.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Empty);
  }

  @Test
  public void testConstructor3() {
    assertEquals(esmCustom.getBoardSize(), 7);
    assertEquals(esmCustom.getSlotAt(0, 2), MarbleSolitaireModelState.SlotState.Empty);
  }

  @Test
  public void testConstructor4() {
    assertEquals(esmCustomBoth.getBoardSize(), 13);
    assertEquals(esmCustomBoth.getSlotAt(0, 4), MarbleSolitaireModelState.SlotState.Empty);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor2ErrorEven() {
    MarbleSolitaireModel error = new EnglishSolitaireModel(2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor2ErrorNegative() {
    MarbleSolitaireModel error = new EnglishSolitaireModel(-3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor3Error() {
    MarbleSolitaireModel error = new EnglishSolitaireModel(99, 99);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor4ErrorTooBig() {
    MarbleSolitaireModel error = new EnglishSolitaireModel(3, 5, 99);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor4ErrorNegative() {
    MarbleSolitaireModel error = new EnglishSolitaireModel(3, -5, 5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor4Error2() {
    MarbleSolitaireModel error = new EnglishSolitaireModel(2, 5, 5);
  }

  @Test
  public void testGetBoardSize() {
    assertEquals(esm.getBoardSize(), 7);
    assertEquals(esm2.getBoardSize(), 13);
    assertEquals(esmCustom.getBoardSize(), 7);
    assertEquals(esmCustomBoth.getBoardSize(), 13);
    assertEquals(new EnglishSolitaireModel(7).getBoardSize(), 19);
  }

  @Test
  public void testIsGameOver() {
    assertEquals(esm.isGameOver(), false);
    EnglishSolitaireModel esmOver = new EnglishSolitaireModel();
    esmOver.makeOver();
    assertEquals(esmOver.isGameOver(), true);

    assertEquals(esm2.isGameOver(), false);
    EnglishSolitaireModel esmOver2 = esm2;
    esmOver2.makeOver();
    assertEquals(esmOver2.isGameOver(), true);

    assertEquals(esmCustom.isGameOver(), false);
    EnglishSolitaireModel esmOverCustom = esmCustom;
    esmOverCustom.makeOver();
    assertEquals(esmOverCustom.isGameOver(), false);

    assertEquals(esmCustomBoth.isGameOver(), false);
    EnglishSolitaireModel esmOverCustomBoth = esmCustomBoth;
    esmOverCustomBoth.makeOver();
    assertEquals(esmOverCustomBoth.isGameOver(), false);


  }

  @Test
  public void testGetScore() {
    assertEquals(esm.getScore(), 32);
    esm.move(5, 3, 3, 3);
    assertEquals(esm.getScore(), 31);

    assertEquals(esm2.getScore(), 104);
    esm2.move(4, 6, 6, 6);
    assertEquals(esm2.getScore(), 103);
  }

  @Test
  public void testGetSlotAt() {
    assertEquals(esm.getSlotAt(0, 0), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(esm.getSlotAt(0, 3), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(esm.getSlotAt(0, 2), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(esm.getSlotAt(4, 0), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(esm.getSlotAt(5, 1), MarbleSolitaireModelState.SlotState.Invalid);

    assertEquals(esm2.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm2.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(esm2.getSlotAt(7, 8), MarbleSolitaireModelState.SlotState.Marble);

    assertEquals(esmCustomBoth.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(esmCustomBoth.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(esmCustomBoth.getSlotAt(7, 8), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(esmCustomBoth.getSlotAt(0, 4), MarbleSolitaireModelState.SlotState.Empty);
  }


  @Test(expected = IllegalArgumentException.class)
  public void testMoveFromDNE() {
    esm.move(0, 0, 3, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveToDNE() {
    esm.move(1, 3, 0, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveFromEmpty() {
    esm.move(3, 3, 1, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveToMarble() {
    esm.move(3, 0, 3, 2);
  }

  @Test
  public void testMove() {

    esm.move(1, 3, 3, 3);
    assertEquals(esm.getSlotAt(1, 3), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm.getSlotAt(2, 3), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Marble);

    esm.move(2, 5, 2, 3);
    assertEquals(esm.getSlotAt(2, 5), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm.getSlotAt(2, 4), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm.getSlotAt(2, 3), MarbleSolitaireModelState.SlotState.Marble);

    esm.move(3, 3, 1, 3);
    assertEquals(esm.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm.getSlotAt(2, 3), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm.getSlotAt(1, 3), MarbleSolitaireModelState.SlotState.Marble);

    esm.move(3, 1, 3, 3);
    assertEquals(esm.getSlotAt(3, 1), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm.getSlotAt(3, 2), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Marble);

    esm2.move(4, 6, 6, 6);
    assertEquals(esm2.getSlotAt(4, 6), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm2.getSlotAt(5, 6), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm2.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Marble);

    esm2.move(5, 8, 5, 6);
    assertEquals(esm2.getSlotAt(5, 8), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm2.getSlotAt(5, 7), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm2.getSlotAt(5, 6), MarbleSolitaireModelState.SlotState.Marble);

    esm2.move(6, 6, 4, 6);
    assertEquals(esm2.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm2.getSlotAt(5, 6), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm2.getSlotAt(4, 6), MarbleSolitaireModelState.SlotState.Marble);

    esm2.move(6, 4, 6, 6);
    assertEquals(esm2.getSlotAt(6, 4), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm2.getSlotAt(6, 5), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(esm2.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Marble);
  }
}
