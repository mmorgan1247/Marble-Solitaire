import org.junit.Test;

//import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.EuropeanSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
//import cs3500.marblesolitaire.view.MarbleSolitaireView;

import static org.junit.Assert.assertEquals;

/**
 * class EuropeanSolitaireModelTest contains test classes
 * for the EuropeanSolitaireModel.
 */
public class EuropeanSolitaireModelTest {
  EuropeanSolitaireModel euro1 = new EuropeanSolitaireModel();
  EuropeanSolitaireModel euro2 = new EuropeanSolitaireModel(5);
  EuropeanSolitaireModel euro3 = new EuropeanSolitaireModel(4, 4);
  EuropeanSolitaireModel euro4 = new EuropeanSolitaireModel(5, 6, 6);


  @Test
  public void testCons1() {
    assertEquals(MarbleSolitaireModelState.SlotState.Empty,
            euro1.getSlotAt(3, 3));
    assertEquals(euro1.getBoardSize(), 7);
  }

  @Test
  public void testCons2() {
    assertEquals(MarbleSolitaireModelState.SlotState.Empty,
            euro2.getSlotAt(6, 6));
    assertEquals(euro2.getBoardSize(), 13);
  }

  @Test
  public void testCons3() {
    assertEquals(MarbleSolitaireModelState.SlotState.Empty,
            euro3.getSlotAt(4, 4));
    assertEquals(euro3.getBoardSize(), 7);
  }

  @Test
  public void testCons4() {
    assertEquals(MarbleSolitaireModelState.SlotState.Empty,
            euro4.getSlotAt(6, 6));
    assertEquals(euro4.getBoardSize(), 13);
  }

  @Test
  public void testGetBoardSize() {
    assertEquals(euro1.getBoardSize(), 7);
    assertEquals(euro2.getBoardSize(), 13);
    assertEquals(euro3.getBoardSize(), 7);
    assertEquals(euro4.getBoardSize(), 13);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveFromDNE() {
    euro1.move(0, 0, 3, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveToDNE() {
    euro1.move(1, 3, 0, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveFromEmpty() {
    euro1.move(3, 3, 1, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveToMarble() {
    euro1.move(3, 0, 3, 2);
  }

  @Test
  public void testGetScore() {
    System.out.println(new MarbleSolitaireTextView(euro1).toString());
    assertEquals(euro1.getScore(), 36);
    euro1.move(5, 3, 3, 3);
    assertEquals(euro1.getScore(), 35);

    assertEquals(euro2.getScore(), 128);
    euro2.move(4, 6, 6, 6);
    assertEquals(euro2.getScore(), 127);

    assertEquals(euro3.getScore(), 36);
    euro3.move(4, 2, 4, 4);
    assertEquals(euro3.getScore(), 35);

    assertEquals(euro4.getScore(), 128);
    euro4.move(6, 4, 6, 6);
    assertEquals(euro4.getScore(), 127);
  }

  /*private void makeOver(EuropeanSolitaireModel euro,
  MarbleSolitaireModelState.SlotState[][] arr, int thickness) {
    for (int row = euro.getBoardSize() - 2; row >= 0; row -= 2) {
      for (int col = euro.getBoardSize() - 2; col >= 0; col--) {
        arr[row][col] = MarbleSolitaireModelState.SlotState.Empty;
        arr[thickness + 1][col] = MarbleSolitaireModelState.SlotState.Empty;
      }

    }

  }*/

  /*@Test
  public void testIsGameOver() {
    assertEquals(euro1.isGameOver(), false);
    euro1.makeOver();
    assertEquals(euro1.isGameOver(), true);

    assertEquals(esm2.isGameOver(), false);
    EnglishSolitaireModel esmOver2 = esm2;
    esmOver2.makeOver();
    assertEquals(esmOver2.isGameOver(), true);

    assertEquals(esmCustom.isGameOver(), false);
    EnglishSolitaireModel esmOverCustom = esmCustom;
    esmOverCustom.makeOver();
    assertEquals(esmOverCustom.isGameOver(), false);

    assertEquals(esmCustomBoth.isGameOver(), false);
    EnglishSolitaireModel esmOverCustomBoth = esmCustomBoth;
    esmOverCustomBoth.makeOver();
    assertEquals(esmOverCustomBoth.isGameOver(), false);


  } */

  @Test(expected = IllegalArgumentException.class)
  public void testCons2Negative() {
    EuropeanSolitaireModel negative = new EuropeanSolitaireModel(-1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCons2Even() {
    EuropeanSolitaireModel even = new EuropeanSolitaireModel(8);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCons3TooBig() {
    EuropeanSolitaireModel big = new EuropeanSolitaireModel(9, 9);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCons3Negative() {
    EuropeanSolitaireModel negative = new EuropeanSolitaireModel(-3, 9);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCons4NegativeThickness() {
    EuropeanSolitaireModel nThickness = new EuropeanSolitaireModel(-1, 3, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCons4NegativeArgs() {
    EuropeanSolitaireModel nArgs = new EuropeanSolitaireModel(3, -2, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCons4BigArgs() {
    EuropeanSolitaireModel bigArgs = new EuropeanSolitaireModel(3, 10, 3);
  }

  @Test
  public void testGetSlotAt() {
    assertEquals(euro1.getSlotAt(0, 0), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(euro1.getSlotAt(0, 1), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(euro1.getSlotAt(1, 0), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(euro1.getSlotAt(1, 1), MarbleSolitaireModelState.SlotState.Marble);


    assertEquals(euro2.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(euro2.getSlotAt(3, 3), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(euro2.getSlotAt(7, 8), MarbleSolitaireModelState.SlotState.Marble);

    assertEquals(euro4.getSlotAt(6, 6), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals(euro4.getSlotAt(2, 1), MarbleSolitaireModelState.SlotState.Invalid);
    assertEquals(euro4.getSlotAt(7, 8), MarbleSolitaireModelState.SlotState.Marble);
    assertEquals(euro4.getSlotAt(9, 1), MarbleSolitaireModelState.SlotState.Marble);
  }

  /*@Test
  public void printSomething() {
    MarbleSolitaireTextView tv = new MarbleSolitaireTextView(euro4);
    //System.out.println(tv.toString());
  }*/


}
