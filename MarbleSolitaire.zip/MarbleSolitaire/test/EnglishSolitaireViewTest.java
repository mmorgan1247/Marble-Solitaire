import org.junit.Test;

import java.io.IOException;

import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

import static org.junit.Assert.assertEquals;

/**
 * Class EnglishSolitaireViewTest tests the methods in
 * MarbleSolitaireView.
 */
public class EnglishSolitaireViewTest {
  EnglishSolitaireModel esm = new EnglishSolitaireModel();
  EnglishSolitaireModel esm2 = new EnglishSolitaireModel(5);
  EnglishSolitaireModel esmCustom = new EnglishSolitaireModel(0, 2);
  EnglishSolitaireModel esmCustomBoth = new EnglishSolitaireModel(5, 0, 4);


  MarbleSolitaireTextView mstv = new MarbleSolitaireTextView(esm);
  MarbleSolitaireTextView mstv2 = new MarbleSolitaireTextView(esm2);
  MarbleSolitaireTextView mstvCustom = new MarbleSolitaireTextView(esmCustom);
  MarbleSolitaireTextView mstvCustomBoth = new MarbleSolitaireTextView(esmCustomBoth);

  MarbleSolitaireView mockView = new MockView();


  @Test(expected = IllegalArgumentException.class)
  public void testConstructor1Null() {
    MarbleSolitaireView view = new MarbleSolitaireTextView(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor2NullModel() {
    MarbleSolitaireView view = new MarbleSolitaireTextView(null, new StringBuilder());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testConstructor2NullReadable() {
    MarbleSolitaireView view = new MarbleSolitaireTextView(esm, null);
  }

  @Test
  public void testToString() {
    assertEquals(mstvCustomBoth.toString(),
            "        _ O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O");

    assertEquals(mstvCustom.toString(),
            "    _ O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O O O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O");
    assertEquals(mstv.toString(),
            "    O O O\n" +
                    "    O O O\n" +
                    "O O O O O O O\n" +
                    "O O O _ O O O\n" +
                    "O O O O O O O\n" +
                    "    O O O\n" +
                    "    O O O");
    assertEquals(mstv2.toString(),
            "        O O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O _ O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "O O O O O O O O O O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O\n" +
                    "        O O O O O");

  }

  @Test
  public void testRenderMessage() {
    Appendable out = new StringBuilder();
    MarbleSolitaireView view = new MarbleSolitaireTextView(
            new EnglishSolitaireModel(), out);
    try {
      view.renderMessage("Message rendered.");
    } catch (Exception iOException) {
      throw new IllegalStateException();
    }
    assertEquals("Message rendered.", out.toString());

  }

  @Test
  public void testRenderBoard() {
    Appendable out = new StringBuilder();
    MarbleSolitaireView view = new MarbleSolitaireTextView(
            new EnglishSolitaireModel(), out);

    try {
      view.renderBoard();
    } catch (Exception iOException) {
      throw new IllegalStateException();
    }

    assertEquals("    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O", out.toString());
  }

  @Test(expected = IOException.class)
  public void testRenderMessageIOException() throws IOException {
    mockView.renderMessage("MACK");
  }

  @Test(expected = IOException.class)
  public void testRenderBoardIOException() throws IOException {
    mockView.renderBoard();
  }


}


