//import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
//import static org.junit.Assert.assertEquals;


/**
 * class MockModel is an implementation of MarbleSolitaireModel
 * that helps test if a MarbleSolitaireController is giving
 * the model's move method correct input through the
 * controller's playGame method.
 */
public class MockModel implements MarbleSolitaireModel {
  private final StringBuilder log;
  private int counter = 0;

  /**
   * MockModel constructor is a mock of the MarbleSolitaireModel
   * that checks the validity of the arguments passed into its move method
   * by a MarbleSolitaireController.
   *
   * @param log where
   */
  MockModel(StringBuilder log) {
    this.log = log;
  }

  @Override
  public void move(int fromRow, int fromCol, int toRow, int toCol) throws IllegalArgumentException {
    log.append((fromRow + 1) + " " + (fromCol + 1) + " " + (toRow + 1) + " " + (toCol + 1));
  }

  @Override
  public boolean isGameOver() {
    counter += 1;
    return counter == 2;
  }

  @Override
  public int getBoardSize() {
    return 0;
  }

  @Override
  public SlotState getSlotAt(int row, int col) throws IllegalArgumentException {
    return null;
  }

  @Override
  public int getScore() {
    return 0;
  }
}


