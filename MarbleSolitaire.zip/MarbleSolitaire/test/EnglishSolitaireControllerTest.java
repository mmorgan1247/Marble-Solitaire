import org.junit.Test;

//import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import cs3500.marblesolitaire.controller.MarbleSolitaireController;
import cs3500.marblesolitaire.controller.MarbleSolitaireControllerImpl;
//import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.EnglishSolitaireModel;
import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModel;
import cs3500.marblesolitaire.view.MarbleSolitaireTextView;
import cs3500.marblesolitaire.view.MarbleSolitaireView;

import static org.junit.Assert.assertEquals;

/**
 * class EnglishSolitaireControllerTest contains
 * methods that test the controller of the
 * marble solitaire game.
 */
public class EnglishSolitaireControllerTest {

  Reader in = new StringReader("2 4 4 4");
  StringBuilder log = new StringBuilder();
  MarbleSolitaireModel mockModel = new MockModel(log);
  MarbleSolitaireModel model = new EnglishSolitaireModel();
  MarbleSolitaireView view = new MarbleSolitaireTextView(mockModel);
  MarbleSolitaireController controllerMockModel = new MarbleSolitaireControllerImpl(
          mockModel, view, in);
  Appendable mockAppendable = new MockAppendable();

  @Test
  public void testControllerToModel() throws Exception {


    //valid move
    controllerMockModel.playGame();
    assertEquals("2 4 4 4", log.toString());


    in = new StringReader(" e e e 2 e r w 4 s 4 e e e 4 e e e");
    log = new StringBuilder();
    mockModel = new MockModel(log);
    view = new MarbleSolitaireTextView(mockModel);
    controllerMockModel = new MarbleSolitaireControllerImpl(mockModel, view, in);

    //unrecognized letters
    controllerMockModel.playGame();
    assertEquals("2 4 4 4", log.toString());

    in = new StringReader("2 -2 4 -2 4 4");
    log = new StringBuilder();
    mockModel = new MockModel(log);
    view = new MarbleSolitaireTextView(mockModel);
    controllerMockModel = new MarbleSolitaireControllerImpl(mockModel, view, in);

    //negative numbers
    controllerMockModel.playGame();
    assertEquals("2 4 4 4", log.toString());

    in = new StringReader(" q 2 3 4 4");
    log = new StringBuilder();
    mockModel = new MockModel(log);
    view = new MarbleSolitaireTextView(mockModel);
    controllerMockModel = new MarbleSolitaireControllerImpl(mockModel, view, in);

    //quit input
    controllerMockModel.playGame();
    assertEquals("1 1 1 1", log.toString());
  }

  @Test(expected = IllegalStateException.class)
  public void testIOExceptionMockAppendable() {
    MarbleSolitaireView viewMockAppendable = new MarbleSolitaireTextView(
            model, mockAppendable);
    MarbleSolitaireController controllerMockAppendable = new MarbleSolitaireControllerImpl(
            new EnglishSolitaireModel(), viewMockAppendable, in);
    controllerMockAppendable.playGame();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testControllerConstructorNullModel() {
    MarbleSolitaireController controllerX = new MarbleSolitaireControllerImpl(
            null, view, in);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testControllerConstructorNullView() {
    MarbleSolitaireController controllerX = new MarbleSolitaireControllerImpl(
            model, null, in);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testControllerConstructorNullReadable() {
    MarbleSolitaireController controllerX = new MarbleSolitaireControllerImpl(
            model, view, null);
  }

  @Test(expected = IllegalStateException.class)
  public void testEmptyReadable() {
    MarbleSolitaireController emptyReadable = new MarbleSolitaireControllerImpl(
            model, view, new StringReader(""));
    emptyReadable.playGame();

  }

  @Test(expected = IllegalStateException.class)
  public void testEmptyReadableAfterSuccessfulMoves() {
    MarbleSolitaireController emptyReadable = new MarbleSolitaireControllerImpl(
            model, view, new StringReader("2 4 4 4 3 2 3 4"));
    emptyReadable.playGame();

  }

  @Test(expected = IllegalStateException.class)
  public void testInvalidInputMoveIOException() {

    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(
            model, new MockView(), new StringReader("2 4 5 66 q"));

    controller.playGame();
  }

  @Test(expected = IllegalStateException.class)
  public void testQuitIOException() {
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(
            model, new MockView(), new StringReader("Q"));
    controller.playGame();
  }

  @Test(expected = IllegalStateException.class)
  public void testGameOverRenderMessageIOException() {
    EnglishSolitaireModel modelOver1 = new EnglishSolitaireModel();
    modelOver1.makeOver();
    MarbleSolitaireModel modelOver = modelOver1;
    view = new MarbleSolitaireTextView(modelOver1, mockAppendable);
    MarbleSolitaireController controllerOver = new MarbleSolitaireControllerImpl(
            modelOver, view, in);
    controllerOver.playGame();
  }

  @Test
  public void testInvalidInputMove() {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    Appendable out = new StringBuilder();
    view = new MarbleSolitaireTextView(model, out);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(
            model, view, new StringReader("2 4 5 66 q"));

    controller.playGame();
    assertEquals(out.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Invalid Input.     O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32");//IMPL LINE 106
  }

  @Test
  public void testQuitNoInputs() {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    Appendable out = new StringBuilder();
    view = new MarbleSolitaireTextView(model, out);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(
            model, view, new StringReader("Q"));
    controller.playGame();
    assertEquals(out.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32");
  }

  @Test
  public void testQuitSomeInputs() {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    Appendable out = new StringBuilder();
    view = new MarbleSolitaireTextView(model, out);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(
            model, view, new StringReader("1 2 2 Q"));
    controller.playGame();
    assertEquals(out.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32");
  }

  @Test
  public void testQuitAfterSuccessfulMove() {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    Appendable out = new StringBuilder();
    view = new MarbleSolitaireTextView(model, out);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(
            model, view, new StringReader("2 4 4 4 Q"));
    controller.playGame();
    assertEquals(out.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "    O O O\n" +
            "    O _ O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O _ O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31");
  }

  @Test
  public void testQuitAfterSuccessfulMoves() {
    MarbleSolitaireModel model = new EnglishSolitaireModel();
    Appendable out = new StringBuilder();
    view = new MarbleSolitaireTextView(model, out);
    MarbleSolitaireController controller = new MarbleSolitaireControllerImpl(
            model, view, new StringReader("2 4 4 4 3 2 3 4 Q"));
    controller.playGame();

    assertEquals(out.toString(), "    O O O\n" +
            "    O O O\n" +
            "O O O O O O O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 32\n" +
            "    O O O\n" +
            "    O _ O\n" +
            "O O O _ O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 31\n" +
            "    O O O\n" +
            "    O _ O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 30\n" +
            "Game quit!\n" +
            "State of game when quit:\n" +
            "    O O O\n" +
            "    O _ O\n" +
            "O _ _ O O O O\n" +
            "O O O O O O O\n" +
            "O O O O O O O\n" +
            "    O O O\n" +
            "    O O O\n" +
            "Score: 30");
  }
}
