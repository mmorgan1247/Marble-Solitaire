import org.junit.Test;

import static org.junit.Assert.assertEquals;

import cs3500.marblesolitaire.model.hw02.MarbleSolitaireModelState;
import cs3500.marblesolitaire.model.hw04.TriangleSolitaireModel;
import cs3500.marblesolitaire.view.TriangleSolitaireTextView;

/**
 * class TriangleSolitaireModelTest contains test methods
 * for the class TriangleSolitaireModel.
 */
public class TriangleSolitaireTest {

  TriangleSolitaireModel tsmCons1 = new TriangleSolitaireModel();
  TriangleSolitaireModel tsmCons2 = new TriangleSolitaireModel(4);
  TriangleSolitaireModel tsmCons3 = new TriangleSolitaireModel(3, 3);
  TriangleSolitaireModel tsmCons4 = new TriangleSolitaireModel(6, 4, 0);

  @Test(expected = IllegalArgumentException.class)
  public void testSecondConstructorError() {
    TriangleSolitaireModel tsm2 = new TriangleSolitaireModel(-1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testThirdConstructorErrorTooBig() {
    TriangleSolitaireModel tsm3Big = new TriangleSolitaireModel(6, 6);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testThirdConstructorErrorTooSmall() {
    TriangleSolitaireModel tsm3Small = new TriangleSolitaireModel(0, -1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFourthConstructorErrorTooBig() {
    TriangleSolitaireModel tsm4Big = new TriangleSolitaireModel(5, 6, 6);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFourthConstructorErrorTooSmall() {
    TriangleSolitaireModel tsm4Small = new TriangleSolitaireModel(5, 0, -1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFourthConstructorError() {
    TriangleSolitaireModel tsm4 = new TriangleSolitaireModel(-1, 0, 0);
  }

  @Test
  public void testGetScore() {
    TriangleSolitaireModel tsm = new TriangleSolitaireModel();
    assertEquals(tsm.getScore(), 14);

    tsm.move(2, 2, 0, 0);
    assertEquals(tsm.getScore(), 13);

    tsm.move(4, 4, 2, 2);
    assertEquals(tsm.getScore(), 12);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveFromDNE() {
    tsmCons1.move(0, 2, 0, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveToDNE() {
    tsmCons1.move(0, 0, 0, 2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveFromEmpty() {
    tsmCons1.move(0, 0, 1, 3);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMoveToMarble() {
    tsmCons1.move(3, 0, 3, 2);
  }

  @Test
  public void testMoveDiagUp() {
    tsmCons1.move(2, 2, 0, 0);
    assertEquals((tsmCons1.getSlotAt(2, 2)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons1.getSlotAt(1, 1)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons1.getSlotAt(0, 0)), MarbleSolitaireModelState.SlotState.Marble);
  }

  @Test
  public void testMoveUp() {
    tsmCons1.move(2, 0, 0, 0);
    assertEquals((tsmCons1.getSlotAt(2, 0)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons1.getSlotAt(1, 0)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons1.getSlotAt(0, 0)), MarbleSolitaireModelState.SlotState.Marble);
  }

  @Test
  public void testMoveLeft() {
    tsmCons4.move(4, 2, 4, 0);
    assertEquals((tsmCons4.getSlotAt(4, 2)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons4.getSlotAt(4, 1)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons4.getSlotAt(4, 0)), MarbleSolitaireModelState.SlotState.Marble);
  }

  @Test
  public void testMoveRight() {
    tsmCons3.move(3, 1, 3, 3);
    assertEquals((tsmCons3.getSlotAt(3, 1)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons3.getSlotAt(3, 2)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons3.getSlotAt(3, 3)), MarbleSolitaireModelState.SlotState.Marble);
  }

  @Test
  public void testMoveDown() {
    tsmCons4.move(2, 0, 4, 0);
    assertEquals((tsmCons4.getSlotAt(2, 0)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons4.getSlotAt(3, 0)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons4.getSlotAt(4, 0)), MarbleSolitaireModelState.SlotState.Marble);
  }

  @Test
  public void testMoveDiagDown() {
    tsmCons3.move(1, 1, 3, 3);
    assertEquals((tsmCons3.getSlotAt(1, 1)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons3.getSlotAt(2, 2)), MarbleSolitaireModelState.SlotState.Empty);
    assertEquals((tsmCons3.getSlotAt(3, 3)), MarbleSolitaireModelState.SlotState.Marble);
  }

  @Test
  public void testTriangleToString() {

    assertEquals(new TriangleSolitaireTextView(tsmCons1).toString(),
            "    _\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O O\n" +
                    "O O O O O");
    //MOVE UP DIAGONAL
    tsmCons1.move(2, 2, 0, 0);
    assertEquals(new TriangleSolitaireTextView(tsmCons1).toString(),
            "    O\n" +
                    "   O _\n" +
                    "  O O _\n" +
                    " O O O O\n" +
                    "O O O O O");

    //MOVE RIGHT
    tsmCons1.move(2, 0, 2, 2);
    assertEquals(new TriangleSolitaireTextView(tsmCons1).toString(),
            "    O\n" +
                    "   O _\n" +
                    "  _ _ O\n" +
                    " O O O O\n" +
                    "O O O O O");

    //MOVE DOWN
    tsmCons1.move(0, 0, 2, 0);
    assertEquals(new TriangleSolitaireTextView(tsmCons1).toString(),
            "    _\n" +
                    "   _ _\n" +
                    "  O _ O\n" +
                    " O O O O\n" +
                    "O O O O O");

    //MOVE UP
    tsmCons1.move(3, 0, 1, 0);
    assertEquals(new TriangleSolitaireTextView(tsmCons1).toString(),
            "    _\n" +
                    "   O _\n" +
                    "  _ _ O\n" +
                    " _ O O O\n" +
                    "O O O O O");

    //MOVE LEFT
    tsmCons1.move(3, 2, 3, 0);
    assertEquals(new TriangleSolitaireTextView(tsmCons1).toString(),
            "    _\n" +
                    "   O _\n" +
                    "  _ _ O\n" +
                    " O _ _ O\n" +
                    "O O O O O");


    assertEquals(new TriangleSolitaireTextView(tsmCons2).toString(),
            "   _\n" +
                    "  O O\n" +
                    " O O O\n" +
                    "O O O O");
    assertEquals(new TriangleSolitaireTextView(tsmCons3).toString(),
            "    O\n" +
                    "   O O\n" +
                    "  O O O\n" +
                    " O O O _\n" +
                    "O O O O O");

    //MOVE DOWN DIAGONAL
    tsmCons3.move(1, 1, 3, 3);
    assertEquals(new TriangleSolitaireTextView(tsmCons3).toString(),
            "    O\n" +
                    "   O _\n" +
                    "  O O _\n" +
                    " O O O O\n" +
                    "O O O O O");
    assertEquals(new TriangleSolitaireTextView(tsmCons4).toString(),
            "     O\n" +
                    "    O O\n" +
                    "   O O O\n" +
                    "  O O O O\n" +
                    " _ O O O O\n" +
                    "O O O O O O");
  }

  @Test
  public void testIsGameOver() {
    assertEquals(tsmCons1.isGameOver(), false);
    tsmCons1.makeOver();
    assertEquals(tsmCons1.isGameOver(), true);
  }
}
